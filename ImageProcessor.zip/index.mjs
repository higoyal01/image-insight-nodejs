import {S3Client} from '@aws-sdk/client-s3';
console.log(S3Client.VERSION);
import {DynamoDBClient, PutItemCommand} from "@aws-sdk/client-dynamodb";
import {Rekognition} from "@aws-sdk/client-rekognition";
import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import {Bedrock} from "@aws-sdk/client-bedrock";

const dynamodbTable = process.env.DYNAMODB_TABLE_NAME;

export const handler = async (event) => {

  const key = event.Records[0].s3.object.key;
  const S3Bucket = event.Records[0].s3.bucket.name;
  // Use Amazon Rekognition to generate a prompt
  const rekognition_client = new Rekognition();
  const rekognitionResponse = await rekognition_client.detectLabels({
    Image: {
      S3Object: {
        Bucket: S3Bucket,
        Name: key,
      },
    },
  });

  // Extract text from the response
  console.log(rekognitionResponse);
  
  // Filter out names with confidence greater than 90
  const detectedText = rekognitionResponse.Labels
    .filter(label => label.Confidence > 90)
    .map(label => label.Name);

  console.log(detectedText);

  // Create a prompt from the detected text
  const prompt = detectedText.join(' ');
  console.log('prompt:', prompt);

  // Use Amazon Bedrock to process the prompt
  
  const BedrockRuntimeClient_ = new Bedrock();
  const foundationModels = await BedrockRuntimeClient_.listFoundationModels({byProvider:'ai21'});
  const matchingModel = foundationModels.modelSummaries.find(model => model.modelName === 'Jurassic-2 Mid');
  
  const body = JSON.stringify({
    prompt,
    maxTokens: 100,
    temperature: 0.4,
    topP: 1,
  });
  console.log('line70', prompt);

  const input = {
    body,
    modelId: matchingModel.modelId,
    accept: 'application/json',
    contentType: 'application/json'
  };
  const invokeModel_ = new BedrockRuntimeClient();
  const command = new InvokeModelCommand(input);
  const bedrockResponse = await invokeModel_.send(command);

  let bedrockResponseBody = Buffer.from(bedrockResponse.body).toString();
  let parsedData = JSON.parse(bedrockResponseBody)
  let output = parsedData.prompt["text"]
  
  // Store the Bedrock service output in DynamoDB
  const dynamoDBClient = new DynamoDBClient();
  const putItemCommand = new PutItemCommand({
    TableName: dynamodbTable,
    Item: {
      'ImageKey': { S: key },
      'Prompt': { S: prompt },
      'BedrockOutput': { S: output },
    },
  });
  const response = await dynamoDBClient.send(putItemCommand);
 
  return output; 
};