import {DynamoDBClient, GetItemCommand} from "@aws-sdk/client-dynamodb";

// Initialize the DynamoDB client
const dynamoDBClient = new DynamoDBClient();

export const handler = async (event, context) => {
  // Extract the value of the 'Key' header from the event
  const path = event.path;
  const parts = path.split('/');
  const bucket = parts[1];
  const key = parts[2];
  console.log(bucket);
  console.log(key);
  const ImageKey = key;

  // Define the DynamoDB table name
  const dynamodb_table = process.env.DYNAMODB_TABLE_NAME;
  console.log(ImageKey);

  try {
    // Query the DynamoDB table based on the key
   
  const gettItemCommand = new GetItemCommand({
      TableName: dynamodb_table,
      Key: {
        'ImageKey': { S: ImageKey }
      }
    });
    const response = await dynamoDBClient.send(gettItemCommand);
    console.log(response)

    // Check if the item was found
    if (response.Item) {
      // Extract the data from DynamoDB
      const item = response.Item;
      const data = item.BedrockOutput.S;

      // Return the data as a JSON response
      return {
        statusCode: 200,
        body: data
      };
    } else {
      // Return a 404 Not Found response if the item was not found
      return {
        statusCode: 404,
        body: JSON.stringify({
          message: 'Item not found'
        })
      };
    }
  } catch (e) {
    // Return an error response if there was an issue with the DynamoDB query
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Internal Server Error',
        error: e.message
      })
    };
  }
};
